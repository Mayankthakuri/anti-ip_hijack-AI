#!/usr/bin/env python3
"""
Anti-Hijack AI Monitor (macOS)
Defensive monitor for browser/network tampering that can impact Safari/Chrome/Firefox.

✅ Detects
- DNS resolver changes / suspicious DNS
- System proxy changes
- /etc/hosts modifications
- Default gateway and gateway MAC changes (ARP spoof signal)
- TLS leaf certificate fingerprint changes for pinned domains
- Optional "AI" anomaly scoring over time (baseline + robust z-score)

Run:
  python3 anti_hijack_ai_monitor.py --once
  python3 anti_hijack_ai_monitor.py --watch --interval 30
  python3 anti_hijack_ai_monitor.py --watch --interval 30 --ai

State/Logs:
  ~/.anti_hijack_ai/state.json
  ~/.anti_hijack_ai/history.jsonl
  ~/.anti_hijack_ai/alerts.log
"""

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

STATE_DIR = Path.home() / ".anti_hijack_ai"
STATE_FILE = STATE_DIR / "state.json"
HISTORY_FILE = STATE_DIR / "history.jsonl"
ALERTS_FILE = STATE_DIR / "alerts.log"

DEFAULT_WATCH_DOMAINS = [
    "apple.com",
    "icloud.com",
    "google.com",
    "paypal.com",
    "coinbase.com",
]

# Common trusted public DNS (not exhaustive)
TRUSTED_DNS_HINTS = {
    "1.1.1.1": "Cloudflare",
    "1.0.0.1": "Cloudflare",
    "8.8.8.8": "Google",
    "8.8.4.4": "Google",
    "9.9.9.9": "Quad9",
    "149.112.112.112": "Quad9",
}

def run(cmd: List[str]) -> Tuple[int, str, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, check=False)
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except Exception as e:
        return 1, "", str(e)

def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8", errors="ignore")).hexdigest()

def ensure_state_dir():
    STATE_DIR.mkdir(parents=True, exist_ok=True)

def load_state() -> Dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_state(state: Dict):
    ensure_state_dir()
    STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")

def append_history(snap: Dict):
    ensure_state_dir()
    with open(HISTORY_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(snap, ensure_ascii=False) + "\n")

def log_alert(msg: str):
    ensure_state_dir()
    line = f"[{now()}] {msg}\n"
    with open(ALERTS_FILE, "a", encoding="utf-8") as f:
        f.write(line)
    print(line, end="")

# ---------------- Checks ----------------

def get_dns_servers() -> List[str]:
    rc, out, _ = run(["scutil", "--dns"])
    if rc != 0:
        return []
    servers = re.findall(r"nameserver\[\d+\]\s*:\s*([0-9a-fA-F\.:]+)", out)
    seen = set()
    uniq = []
    for s in servers:
        if s not in seen:
            seen.add(s)
            uniq.append(s)
    return uniq

def dns_risk(dns_servers: List[str]) -> Dict:
    """
    Heuristic risk hints:
    - Empty DNS list (unusual)
    - Presence of unknown public resolvers when you expect local/router DNS
    - Very frequent changes (handled by AI score in watch mode)
    """
    hints = []
    score = 0

    if not dns_servers:
        hints.append("DNS list is empty (unusual).")
        score += 2

    for s in dns_servers:
        if s in TRUSTED_DNS_HINTS:
            hints.append(f"DNS includes {s} ({TRUSTED_DNS_HINTS[s]}).")
        # Rough heuristic: public DNS often not in RFC1918; if you expect router DNS (192.168.x.x etc),
        # seeing many public IPs could be fine or could be forced DNS. We just flag as "review".
        if re.match(r"^\d+\.\d+\.\d+\.\d+$", s):
            oct1 = int(s.split(".")[0])
            if oct1 not in (10, 172, 192, 127):
                score += 1

    if score >= 3:
        risk = "high"
    elif score == 2:
        risk = "medium"
    elif score == 1:
        risk = "low"
    else:
        risk = "info"

    return {"risk": risk, "score": score, "hints": hints}

def get_proxy_state() -> Dict[str, str]:
    rc, out, _ = run(["networksetup", "-listallnetworkservices"])
    if rc != 0:
        return {}
    services = [line.strip() for line in out.splitlines()
                if line.strip() and not line.startswith("An asterisk")]
    proxy_info = {}
    for svc in services:
        rc1, wout, _ = run(["networksetup", "-getwebproxy", svc])
        rc2, sout, _ = run(["networksetup", "-getsecurewebproxy", svc])
        if rc1 == 0:
            proxy_info[f"{svc}:web"] = wout
        if rc2 == 0:
            proxy_info[f"{svc}:secureweb"] = sout
    return proxy_info

def hosts_hash() -> Optional[str]:
    p = Path("/etc/hosts")
    if not p.exists():
        return None
    try:
        return sha256_text(p.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return None

def get_default_route() -> str:
    rc, out, _ = run(["route", "-n", "get", "default"])
    if rc != 0:
        return ""
    m = re.search(r"gateway:\s+([0-9a-fA-F\.:]+)", out)
    return m.group(1) if m else ""

def get_wifi_ssid() -> str:
    airport = "/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport"
    if not os.path.exists(airport):
        return ""
    rc, out, _ = run([airport, "-I"])
    if rc != 0:
        return ""
    m = re.search(r"^\s*SSID:\s*(.+)$", out, re.MULTILINE)
    return m.group(1).strip() if m else ""

def get_gateway_arp(gateway_ip: str) -> str:
    if not gateway_ip:
        return ""
    rc, out, _ = run(["arp", "-n", gateway_ip])
    if rc != 0:
        return ""
    m = re.search(r" at ([0-9a-f:]{17}) ", out.lower())
    return m.group(1) if m else ""

def tls_cert_fingerprint_sha256(domain: str, port: int = 443) -> str:
    """
    Retrieves leaf certificate PEM and hashes it (change detection).
    """
    cmd = [
        "bash", "-lc",
        f"echo | openssl s_client -servername {domain} -connect {domain}:{port} -showcerts 2>/dev/null "
        f"| awk '/BEGIN CERTIFICATE/,/END CERTIFICATE/ {{print}}' | head -n 2000"
    ]
    rc, out, _ = run(cmd)
    if rc != 0 or "BEGIN CERTIFICATE" not in out:
        return ""
    return sha256_text(out)

# ---------------- AI features (defensive) ----------------

def robust_zscore(curr: float, series: List[float]) -> float:
    """
    Robust z-score using median and MAD.
    Returns 0 if insufficient data.
    """
    if len(series) < 12:
        return 0.0
    s = sorted(series)
    mid = len(s)//2
    median = (s[mid] if len(s)%2 else (s[mid-1]+s[mid])/2.0)
    abs_dev = [abs(x - median) for x in series]
    abs_dev_sorted = sorted(abs_dev)
    mid2 = len(abs_dev_sorted)//2
    mad = (abs_dev_sorted[mid2] if len(abs_dev_sorted)%2 else (abs_dev_sorted[mid2-1]+abs_dev_sorted[mid2])/2.0)
    if mad == 0:
        return 0.0
    return 0.6745 * (curr - median) / mad  # 0.6745 makes MAD comparable to std

def ai_anomaly_score(curr_snap: Dict) -> Dict:
    """
    Converts snapshot to numeric features and scores anomalies vs history.
    - Feature 1: number of DNS servers
    - Feature 2: number of proxy configs containing 'Enabled: Yes'
    - Feature 3: cert failures count (empty fp)
    - Feature 4: "public DNS count" (non-RFC1918)
    Higher |z| => more anomalous.
    """
    history = []
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                for line in f.readlines()[-500:]:
                    history.append(json.loads(line))
        except Exception:
            history = []

    def is_public_ip(ip: str) -> bool:
        if not re.match(r"^\d+\.\d+\.\d+\.\d+$", ip):
            return False
        a,b,c,d = [int(x) for x in ip.split(".")]
        if a == 10:
            return False
        if a == 172 and 16 <= b <= 31:
            return False
        if a == 192 and b == 168:
            return False
        if a == 127:
            return False
        return True

    dns = curr_snap.get("dns_servers", [])
    proxy = curr_snap.get("proxy_state", {})
    certs = curr_snap.get("tls_cert_fp", {})

    f1 = float(len(dns))
    f2 = float(sum(1 for v in proxy.values() if "Enabled: Yes" in v))
    f3 = float(sum(1 for v in certs.values() if not v))
    f4 = float(sum(1 for ip in dns if is_public_ip(ip)))

    series_f1 = [float(len(h.get("dns_servers", []))) for h in history if isinstance(h, dict)]
    series_f2 = [float(sum(1 for v in h.get("proxy_state", {}).values() if "Enabled: Yes" in v)) for h in history if isinstance(h, dict)]
    series_f3 = [float(sum(1 for v in h.get("tls_cert_fp", {}).values() if not v)) for h in history if isinstance(h, dict)]
    series_f4 = [float(sum(1 for ip in h.get("dns_servers", []) if is_public_ip(ip))) for h in history if isinstance(h, dict)]

    z1 = robust_zscore(f1, series_f1)
    z2 = robust_zscore(f2, series_f2)
    z3 = robust_zscore(f3, series_f3)
    z4 = robust_zscore(f4, series_f4)

    # Combine
    score = abs(z1) + abs(z2) + abs(z3) + abs(z4)

    level = "info"
    if score >= 8:
        level = "high"
    elif score >= 5:
        level = "medium"
    elif score >= 3:
        level = "low"

    return {
        "level": level,
        "score": round(score, 3),
        "z": {"dns_count": round(z1, 3), "proxy_enabled": round(z2, 3),
              "cert_failures": round(z3, 3), "public_dns_count": round(z4, 3)},
        "features": {"dns_count": f1, "proxy_enabled": f2, "cert_failures": f3, "public_dns_count": f4},
        "history_points": len(history),
    }

# ---------------- Core logic ----------------

def snapshot(domains: List[str]) -> Dict:
    dns = get_dns_servers()
    proxy = get_proxy_state()
    hhash = hosts_hash()
    gw = get_default_route()
    gw_mac = get_gateway_arp(gw)
    ssid = get_wifi_ssid()

    certs = {}
    for d in domains:
        certs[d] = tls_cert_fingerprint_sha256(d)

    snap = {
        "time": now(),
        "dns_servers": dns,
        "dns_risk": dns_risk(dns),
        "proxy_state": proxy,
        "hosts_hash": hhash,
        "default_gateway": gw,
        "gateway_mac": gw_mac,
        "wifi_ssid": ssid,
        "tls_cert_fp": certs,
    }
    return snap

def diff_and_alert(prev: Dict, curr: Dict):
    if prev.get("dns_servers") and curr.get("dns_servers") and prev["dns_servers"] != curr["dns_servers"]:
        log_alert(f"⚠️ DNS servers changed:\n  before={prev['dns_servers']}\n  now   ={curr['dns_servers']}")

    if prev.get("proxy_state") and curr.get("proxy_state") and prev["proxy_state"] != curr["proxy_state"]:
        log_alert("⚠️ Proxy settings changed. Review System Settings → Network → Proxies.")

    if prev.get("hosts_hash") and curr.get("hosts_hash") and prev["hosts_hash"] != curr["hosts_hash"]:
        log_alert("⚠️ /etc/hosts changed. Inspect /etc/hosts for suspicious domain overrides.")

    if prev.get("default_gateway") and curr.get("default_gateway") and prev["default_gateway"] != curr["default_gateway"]:
        log_alert(f"⚠️ Default gateway changed:\n  before={prev['default_gateway']}\n  now   ={curr['default_gateway']}")

    if prev.get("gateway_mac") and curr.get("gateway_mac") and prev["gateway_mac"] != curr["gateway_mac"]:
        log_alert(f"🚨 Gateway MAC changed (ARP spoof/MITM risk):\n  before={prev['gateway_mac']}\n  now   ={curr['gateway_mac']}")

    if prev.get("wifi_ssid") and curr.get("wifi_ssid") and prev["wifi_ssid"] != curr["wifi_ssid"]:
        log_alert(f"ℹ️ Wi‑Fi network changed:\n  before={prev['wifi_ssid']}\n  now   ={curr['wifi_ssid']}")

    prev_c = prev.get("tls_cert_fp", {})
    curr_c = curr.get("tls_cert_fp", {})
    for d, new_fp in curr_c.items():
        old_fp = prev_c.get(d, "")
        if old_fp and new_fp and old_fp != new_fp:
            log_alert(f"🚨 TLS cert fingerprint changed for {d} (possible TLS interception / captive portal / MITM).")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--watch", action="store_true", help="Run continuously")
    parser.add_argument("--interval", type=int, default=30, help="Seconds between checks (watch mode)")
    parser.add_argument("--once", action="store_true", help="Run once and print snapshot + diff")
    parser.add_argument("--ai", action="store_true", help="Enable AI anomaly scoring over time (baseline learning)")
    parser.add_argument("--domains", type=str, default=",".join(DEFAULT_WATCH_DOMAINS),
                        help="Comma-separated domains to pin cert fingerprints")
    args = parser.parse_args()

    domains = [d.strip() for d in args.domains.split(",") if d.strip()]
    state = load_state()

    if args.once and not args.watch:
        curr = snapshot(domains)
        if args.ai:
            curr["ai"] = ai_anomaly_score(curr)
        print(json.dumps(curr, indent=2))
        if state:
            diff_and_alert(state, curr)
        save_state(curr)
        append_history(curr)
        return

    if not args.watch and not args.once:
        args.watch = True

    while True:
        curr = snapshot(domains)
        if args.ai:
            curr["ai"] = ai_anomaly_score(curr)

        if state:
            diff_and_alert(state, curr)
        else:
            log_alert("✅ Baseline created. Next changes will be alerted.")

        # AI alerting
        if args.ai:
            ai = curr.get("ai", {})
            level = ai.get("level", "info")
            if level in ("medium", "high"):
                log_alert(f"🧠 AI anomaly level={level} score={ai.get('score')} z={ai.get('z')} features={ai.get('features')}")

        # DNS heuristic risk
        dr = curr.get("dns_risk", {})
        if dr.get("risk") in ("medium", "high"):
            log_alert(f"🛡 DNS risk={dr.get('risk')} score={dr.get('score')} hints={dr.get('hints')}")

        save_state(curr)
        append_history(curr)
        state = curr

        time.sleep(max(5, args.interval))

if __name__ == "__main__":
    if sys.platform != "darwin":
        print("This script is designed for macOS (darwin).", file=sys.stderr)
    main()
